package com.android.qooveechats.Adapters

import android.content.Context
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import com.android.qooveechats.Fragments.ChatFragment
import com.android.qooveechats.Fragments.ListChatFragment

class PageAdapter (val mContext: Context, fm: FragmentManager) : FragmentStatePagerAdapter(fm) {

    override fun getCount(): Int {
        return 2
    }

    override fun getItem(position: Int): Fragment {

        return when (position) {
            0 ->{
                ListChatFragment.newInstance()
            }

            else -> ChatFragment.newInstance()
        }
    }

    override fun getPageTitle(position: Int): CharSequence {
        return when (position) {
            0 -> "Contacts"
            1 -> "Chat"

            else -> "Contacts"
        }
    }
}