package com.android.qooveechats.Listeners

import com.tinder.scarlet.WebSocket
import com.tinder.scarlet.ws.Receive
import io.reactivex.Flowable

interface ChatListener {

    @Receive
    fun observeonConnectionOpenedEvent(): Flowable<WebSocket.Event.OnConnectionOpened<*>>

    /*@Receive
    fun observeTicker(): Flowable<Ticker>*/
}